
//services drop up menu
// -------------------------------------------------sourcing solutions
jQuery(document).ready(function(){
	jQuery(".drop-up").click(function(){
		jQuery(".single1").toggle();
	});
	
});

// water ripple
jQuery(document).ready(function(){
	jQuery('.water-riple').ripples({
		dropRadius: 20,
		perturbance: .04,
		resolution:256,
		interactive:true,
		dropRadius:10,	
	});		
});

//typed js
ityped.init(document.querySelector("#text-shadow"), {
     showCursor: false,
      strings: ['Hi ! I am Luish','YOUR STANDARD PORTFOLIO','I AM A CREATIVE DESIGNER', 'I LOVE DESIGN', 'DESIGN IS MY PASSION'],
	  typespeed:0
 });
	//services area animaton
jQuery(document).ready(function(){
     new WOW().init();
});
jQuery(document).ready(function(){
	jQuery('.skills-first').each(function(){
		jQuery(this).find('.skills-property').animate({
			width:jQuery(this).attr('data-percent')
		},6000);
	});
});

//mixitup recent works area 

jQuery(document).ready(function(){
        var containerEl = document.querySelector('.portfolio-images1');

        var mixer = mixitup(containerEl);
    });
//mixitup hover first images area
jQuery(document).ready(function(){
	jQuery(".first-image-hover").hover(function(){
		jQuery(".hover-text").fadeIn(2000)
	},
		function(){
			 jQuery(".hover-text").fadeOut(2000);//fade slidedown r poriborta ami slideToggle o use korta pari
		
	});
});
//mixitup hover seccond images area
jQuery(document).ready(function(){
	jQuery(".first-image-hover1").hover(function(){
		jQuery(".hover-text1").fadeIn(2000)
	},
		function(){
			 jQuery(".hover-text1").fadeOut(2000);//fade slidedown r poriborta ami slideToggle o use korta pari
		
	});
});
//mixitup hover third images area
jQuery(document).ready(function(){
	jQuery(".first-image-hover2").hover(function(){
		jQuery(".hover-text2").fadeIn(2000)
	},
		function(){
			 jQuery(".hover-text2").fadeOut(2000);//slideup slidedown r poriborta ami slideToggle o use korta pari
		
	});
});	
//mixitup hover fourth images area
jQuery(document).ready(function(){
	jQuery(".first-image-hover3").hover(function(){
		jQuery(".hover-text3").fadeIn(2000)
	},
		function(){
			 jQuery(".hover-text3").fadeOut(2000);//fade slidedown r poriborta ami slideToggle o use korta pari
		
	});
});
//mixitup hover fifth images area
jQuery(document).ready(function(){
	jQuery(".first-image-hover4").hover(function(){
		jQuery(".hover-text4").fadeIn(2000)
	},
		function(){
			 jQuery(".hover-text4").fadeOut(2000);//fade slidedown r poriborta ami slideToggle o use korta pari
		
	});
});
//mixitup hover sixth images area
jQuery(document).ready(function(){
	jQuery(".first-image-hover5").hover(function(){
		jQuery(".hover-text5").fadeIn(2000)
	},
		function(){
			 jQuery(".hover-text5").fadeOut(2000);//fade slidedown r poriborta ami slideToggle o use korta pari
		
	});
});

	// skills area animation-----------------------------------------------
jQuery(document).ready(function(){
	jQuery(".html-skill").animate({'left':'88%'},2000);
	jQuery(".css-skill").animate({'left':'80%'},2000);
	jQuery(".bootstrap-skill").animate({'left':'88%'},2000);
	jQuery(".javascript-skill").animate({'left':'80%'},2000);
	jQuery(".jquery-skill").animate({'left':'85%'},2000);
	jQuery(".programming-skill").animate({'left':'80%'},2000);
});
// counter js
 jQuery(document).ready(function ($) {
     $('.counter').counterUp({
         delay: 10,
         time: 1000
     });
 });
 	// Scroll down start
jQuery(document).ready(function(){
     jQuery('.scroll').click(function(){
		    jQuery('html, body') .animate({
				scrollTop:0},2050);
			});         
}); 
// Scroll down end

	//loading animaton
jQuery(document).ready(function(){
    jQuery('.before-load').preloadinator({
			minTime: 6
		});
});
//color box
jQuery("span.red_color").click(function(){
		jQuery("body").addClass("red_color_bar").removeClass("green_color_bar yellow_color_bar blue_color_bar black_color_bar purple_color_bar");
	});
	jQuery("span.green_color").click(function(){
		jQuery("body").addClass("green_color_bar").removeClass("red_color_bar yellow_color_bar blue_color_bar black_color_bar purple_color_bar");
	});
	jQuery("span.yellow_color").click(function(){
		jQuery("body").addClass("yellow_color_bar").removeClass("red_color_bar green_color_bar blue_color_bar black_color_bar purple_color_bar");
	});
	jQuery("span.blue_color").click(function(){
		jQuery("body").addClass("blue_color_bar").removeClass("red_color_bar green_color_bar yellow_color_bar black_color_bar purple_color_bar");
	});
	jQuery("span.black_color").click(function(){
		jQuery("body").addClass("black_color_bar").removeClass("red_color_bar green_color_bar yellow_color_bar blue_color_bar purple_color_bar");
	});
	jQuery("span.purple_color").click(function(){
		jQuery("body").addClass("purple_color_bar").removeClass("red_color_bar green_color_bar yellow_color_bar blue_color_bar black_color_bar");
	});
	/*spainer*/
	jQuery(".spainer_button").click(function(event){
		event.preventDefault();
		if(jQuery(this).hasClass(".show_spain")){
			jQuery(".color_box").stop().animate({left:"-200px"},500);
		}
		else{
			jQuery(".color_box").stop().animate({left:"0px"},500);
		}
		jQuery(this).toggleClass(".show_spain");
		return false;
	});